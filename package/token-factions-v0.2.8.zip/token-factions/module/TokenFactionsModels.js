export class FactionGraphic {
}
